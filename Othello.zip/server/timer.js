class Timer{
    constructor() {
        this.sec = 120;
    }

    restartTimer(){
        this.sec = 120;
    }

    countDown() {

        timer = setInterval(function() {
            sec--;
            if (sec === 0) {
                // callUpdate();
            }
        }, 1000);
    }

}

const timer = new Timer();
module.exports = timer;